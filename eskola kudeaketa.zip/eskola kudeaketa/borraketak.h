#ifndef BORRAKETAK_H
#define BORRAKETAK_H
#include "egiturak.h"
void borratugela(ESKOLA_t *);
void borratuikasle(ESKOLA_t *);
void borratueskola(INDIZEA_t **, int *);
#endif