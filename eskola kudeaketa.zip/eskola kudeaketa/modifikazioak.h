//
//  modifikazioak.h
//  eskola kudeaketa
//
//  Created by Gorka Olalde on 14/06/14.
//  Copyright (c) 2014 Gorka Olalde. All rights reserved.
//

#ifndef MODIFIKAZIOAK_H
#define MODIFIKAZIOAK_H
void modifikatuikasle(ESKOLA_t **);
JAIO_t modifikatujaiotza();
HELBIDE_t modifikatuhelbidea();
void modifikatugela(ESKOLA_t **);
void mugituikasle(ESKOLA_t **);
#endif