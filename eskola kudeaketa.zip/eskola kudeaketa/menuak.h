#ifndef MENUAK_H
#define MENUAK_H
void menusortuikasgai(IKASGAI_t **, ERABILTZAILE_t *);
void sartunotakmenu(IKASGAI_t **, ERABILTZAILE_t*);
void menueskolanagusia(ESKOLA_t *);
void menuadmin(INDIZEA_t **, int *, ESKOLA_t **);
void menunagusia(INDIZEA_t *, int *);
void menuidazk(ESKOLA_t **);
void menuirakasle(ESKOLA_t *, ERABILTZAILE_t *);
void notaksartumenu(ESKOLA_t *, ERABILTZAILE_t *);
void menuikasle(ESKOLA_t *);
#endif