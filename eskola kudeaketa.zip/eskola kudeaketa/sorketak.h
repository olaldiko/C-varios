#ifndef SORKETAK_H
#define SORKETAK_H
#include "egiturak.h"
void sortuikasle(ESKOLA_t **);
void sortugela(ESKOLA_t **);
void sortuikasgai(IKASGAI_t **, ERABILTZAILE_t *);
void sortueskola(INDIZEA_t **,ESKOLA_t **, int *);
void sortuerabiltzaile(ERABILTZAILE_t **);
#endif